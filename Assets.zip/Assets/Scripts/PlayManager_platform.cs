using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using Assets.Script.entity;
using Assets.Script.globalVar;
using TMPro;

public class PlayManager_platform : MonoBehaviour
{
   
    public GlobalData globalVar;
    public GameObject grass; //prefab

    // Start is called before the first frame update
    void Start()
    {
        //grass = Resources.Load("Assets/Resources/Prefabs/land/grass.prefab") as GameObject;
        Instantiate(grass, new Vector3(0, 0, 0), Quaternion.identity);
    }

    public void fire()
    {
       
    }
    public void stopFire()
    {
       
    }

    // Update is called once per frame
    void Update()
    {

    }

    void reload()
    {
    
    }
    private int createRandomNumber(int min, int max)
    {
       return 0;
    }
    public void countEnemyandSetSliderValue(int enemyCount)
    {
       
    }

    public void instantiateEnemy()
    {
       


    }

}
