using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using Assets.Script.globalVar;
using TMPro.Examples;
public class EnemyEntity : MonoBehaviour
{

    public Vector3 startPos;
    public float heroPositionX;
    private Rigidbody2D rb;
    private Animator anim;
    private float Life;

    private GameObject LifeSliderObject;
    private Slider LifeSlider;

    private Transform coinObject;


    private Transform lifeCanvas;
    private LifeBar life;

    private bool dead = false;

    public GlobalData globalVar;

    private SpriteRenderer renderer;

    private bool invisible = true;

    private bool heroIsHitting = false;

    public Vector3 heroLifePos;
    private Coin Coin;

    private GameObject baseGround;
    private RectTransform baseRect;

    private GameObject upperHeightLimit;
    private GameObject lowerHeightLimit;

    public string enemytag;
    // Start is called before the first frame update
    void Start()
    {

        gameObject.transform.localPosition = new Vector3(gameObject.transform.localPosition.x, gameObject.transform.localPosition.y, 0);
        Debug.Log(Camera.main.ScreenToWorldPoint(gameObject.transform.position));
        Debug.Log(gameObject.transform.localPosition);
        lifeCanvas = gameObject.transform.GetChild(0);
        life = lifeCanvas.gameObject.GetComponent<LifeBar>();

        renderer = gameObject.GetComponent<SpriteRenderer>();
        rb = gameObject.GetComponent<Rigidbody2D>();
        Life = 100;
        anim = gameObject.GetComponent<Animator>();
        LifeSliderObject = transform.GetChild(0).GetChild(0).gameObject;
        LifeSlider = LifeSliderObject.GetComponent<Slider>();
        LifeSlider.value = Life;

        coinObject = gameObject.transform.Find("coin");

        go();

    }

    public void GetHit(int impact)
    {
        if (LifeSlider)
        {
            anim.SetBool("isHurt", true);
            life.fadeIn();
            life.hitting = true;
            LifeSlider.value = LifeSlider.value - impact;
            Life = Life - impact;
        }
    }

    public void go()
    {
        rb.velocity = new Vector2(heroPositionX, transform.position.y) * .08f;
    }

    public void stop()
    {
        rb.velocity = new Vector2(0, 0);
    }

    private IEnumerator OnTriggerEnter2D(Collider2D Obj)
    {
        if (Obj.gameObject.name == "bullet(Clone)" && globalVar.firstEnemy == null)
        {
            Life -= 20;
            LifeSlider.value = Life;
            anim.SetBool("isHurt", true);
            life.fadeIn();
            life.hitting = true;
            yield return new WaitForSeconds(1);
            life.hitting = false;
            anim.SetBool("isHurt", false);
        }
        // else if (Obj.gameObject.tag == "Enemy" && invisible)
        // {
        //     var randomYPosition = Random.Range(-2, 2);
        //     Vector2 movPos;
        //     // gameObject.transform.position = new Vector3(Obj.gameObject.transform.position.x + 1, Obj.gameObject.transform.position.y + randomYPosition, gameObject.transform.position.z);
        //     // Debug.Log(gameObject.transform.position);
        //     // Debug.Log(upperHeightLimit.transform.position);
        //     // Debug.Log(lowerHeightLimit.transform.position);
        // }
        else if (Obj.gameObject.name == "Hero")
        {
            heroIsHitting = true;
            anim.SetBool("Attacking", true);
            stop();
        }
    }

    // public Vector3 worldToUISpace(GameObject parentCanvas, Vector3 worldPos)
    // {
    //     //Convert the world for screen point so that it can be used with ScreenPointToLocalPointInRectangle function
    //     Vector3 screenPos = Camera.main.WorldToScreenPoint(worldPos);
    //     Vector2 movePos;


    //     //Convert the screenpoint to ui rectangle local point
    //     RectTransformUtility.ScreenPointToLocalPointInRectangle(parentCanvas.transform as RectTransform, screenPos, Camera.main, out movePos);
    //     //Convert the local point to world point
    //     return parentCanvas.transform.TransformPoint(movePos);
    // }

    void OnBecameVisible()
    {
        // heroLifePos = GameObject.Find("coinEndPosition");
        // Debug.Log("Hurray");
        invisible = false;
    }

    // private void OnTriggerExit2D(Collider2D bullet)
    // {
    // if(bullet.gameObject.name == "bullet(Clone)")
    // {
    // 	life.hitting = false;
    // }
    // }


    void die()
    {
        dead = true;
        rb.velocity = new Vector2(0, 0);
        anim.SetTrigger("isDie");
        startFadingOut();
        globalVar.bornEnemy.Remove(enemytag);
        if (globalVar.bornEnemy.Count == 0)
        {
            globalVar.instantiateEnemy = true;
        }
        // CHECKING GLOBAl VAR'S heroIsHitting TRUE OR FALSE IF TRUE MAKE iT FALSE

        if (heroIsHitting)
        {
            heroIsHitting = false;
            globalVar.heroIsHitting = false;
        }
    }


    IEnumerator fadeOut()
    {
        for (float f = 1f; f >= -1f; f -= 0.01f)
        {
            Color c = renderer.color;
            c.a = f;
            renderer.color = c;
            yield return new WaitForSeconds(0.05f);
        }
    }

    public void startFadingOut()
    {
        StartCoroutine("fadeOut");

    }

    private void deActivate()
    {
        // Debug.Log(gameObject.activeSelf);
        //if(!coinObject.gameObject.activeSelf){
        gameObject.SetActive(false);
        // gameObject.transform.position = startPos;
        GameObject coinObject = Resources.Load("attackPrefab/coin") as GameObject;
        // coinObject.transform.position = gameObject.transform.position;
        // GameObject coin = GameObject.Instantiate(coinObject);
        // Coin = coin.GetComponent<Coin>();
        // Coin.setGlobalVar(globalVar);
        // Coin.lifeBarPos = heroLifePos;
        //}
    }



    // Update is called once per frame
    void Update()
    {
        // CHECKING HERO IS HITTING OR NOT 
        if (heroIsHitting)
        {
            globalVar.heroIsHitting = true;
        }
        // // Debug.Log(dead);
        if (renderer.color.a < .1)
        {
            StopCoroutine("fadeOut");
            deActivate();
        }

        // if (transform.position.x < heroPositionX + 3)
        // {
        //     rb.velocity = new Vector2(0, 0);
        //     if (!dead)
        //     {
        //         heroIsHitting = true;
        //     }
        // }
        // if (gameObject.transform.position.y < lowerHeightLimit.transform.position.y || gameObject.transform.position.y > upperHeightLimit.transform.position.y)
        // {
        //     var randomYPosition = Random.Range(-2.00f, 2.00f);
        //     gameObject.transform.position = new Vector3(gameObject.transform.position.x, randomYPosition, gameObject.transform.position.z);
        // }

        if (Life == 0 && !dead || Life < 0 && !dead)
        {
            die();
        }
    }

}

