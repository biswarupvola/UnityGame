using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using Assets.Script.globalVar;
using UnityEngine.UI;

namespace Assets.Script.entity

{
    public class HeroEntity : MonoBehaviour
    {

        [SerializeField] public GameObject FirePoint;
        [SerializeField] public GameObject bulletTrails;
        [SerializeField] public float _weaponRange = 10f;
        public Transform Bullet;
        public Rigidbody2D BulletRB;
        public LineRenderer lineRenderer;
        private GameObject HeroLifeBar;

        private Slider LifeBar;
        private float HeroLife = 100f;

        public GlobalData GlobalVar;

        // Start is called before the first frame update
        void Start()
        {
            HeroLifeBar = GameObject.Find("HeroLifeBar");
            if (HeroLifeBar)
            {
                LifeBar = HeroLifeBar.GetComponent<Slider>();
                LifeBar.maxValue = 100f;
                LifeBar.value = HeroLife;
            }

            Bullet = gameObject.transform.Find("09");
            if (Bullet)
            {
                Bullet.position = FirePoint.transform.position;
                BulletRB = Bullet.gameObject.GetComponent<Rigidbody2D>();
            }
        }

        public void countEnemyandSetSliderValue(int enemyCount)
        {

        }

        private int createRandomNumber(int min, int max)
        {
            return 0;
        }

        public void instantiateEnemy()
        {


        }

        void reload()
        {

        }

        public void idle()
        {
        }
        IEnumerator fireCoroutine()
        {
            if (FirePoint)
            {
                RaycastHit2D hit = Physics2D.Raycast(FirePoint.transform.position, FirePoint.transform.right);
                lineRenderer.enabled = true;
                // wait 
                yield return new WaitForSeconds(0.02f);
                lineRenderer.enabled = false;
                if (hit)
                {
                    // Destroy(GameObject.Find(hit.collider.gameObject.name));
                    lineRenderer.SetPosition(0, FirePoint.transform.position);
                    lineRenderer.SetPosition(0, hit.transform.position);
                }
                else
                {
                    lineRenderer.SetPosition(0, FirePoint.transform.position);
                    lineRenderer.SetPosition(0, FirePoint.transform.right * 100);
                }
            }
        }
        public void fire(Vector2 Target)
        {
            // StartCoroutine(fireCoroutine());
            Vector3 pos = new Vector3(Target.x, Target.y, 0);
            var trails = Instantiate(bulletTrails, FirePoint.transform.position, transform.rotation);
            trails.SetActive(true);
            Bullet tailScript = trails.GetComponent<Bullet>();
            if (tailScript)
                tailScript.SetTragetPosition(pos);
        }
        // Update is called once per frame
        void Update()
        {

        }
        void FixedUpdate()
        {
            // if (GlobalVar.heroIsHitting)
            // {
            //     HeroLife = GlobalVar.heroLife -= .2f;
            //     LifeBar.value = HeroLife;
            // }
        }


    }
}