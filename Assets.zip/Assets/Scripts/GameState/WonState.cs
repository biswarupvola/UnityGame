using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using Assets.Script.entity;
using Assets.Script.globalVar;

namespace Assets.Script.state
{


    public class WonState : GameState
    {
        private GameManager manager;
        public string stateName;

        public GlobalData globalVar;

        private GameObject playButtonObject;
        private Button playButton;

        private GameObject menuButtonObject;
        private Button menuButton;

        public WonState(GameManager managerRef, GlobalData globalRef)
        {
            manager = managerRef;
            globalVar = globalRef;
            stateName = "lostState";
        }

        public void getData()
        {

            playButtonObject = GameObject.Find("PlayButton");
            playButton = playButtonObject.GetComponent<Button>();


            menuButtonObject = GameObject.Find("MenuButton");
            menuButton = menuButtonObject.GetComponent<Button>();

            playButton.onClick.AddListener(this.playAgain);
            menuButton.onClick.AddListener(this.goTomenu);

            manager.UnlockRound(globalVar.CurrentLevel + 1);

        }

        void playAgain()
        {
            SceneManager.LoadScene("loader");
            manager.switchState(new LoaderState(manager, globalVar, "Play"));
        }

        void goTomenu()
        {
            // SceneManager.LoadScene("menuState");
            //   manager.switchState(new menuState(manager,globalVar));

            SceneManager.LoadScene("loader");
            manager.switchState(new LoaderState(manager, globalVar, "Menu"));
        }

        public void stateUpdate()
        {
        }
        public string getStateName()
        {
            return this.stateName;
        }
        public void action(string action)
        {

        }

    }

}



