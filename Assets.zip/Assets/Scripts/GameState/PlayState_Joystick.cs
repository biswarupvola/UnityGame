using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using Assets.Script.entity;
using Assets.Script.globalVar;

namespace Assets.Script.state
{
    public class PlayState_Joystick : GameState
    {
        private GameManager manager;
        public string stateName;

        public GameObject HeroObject;
        // public GameObject PlayManagerObject;
        // public PlayManager PlayManagerScript;
        public HeroEntity Hero;

        public GlobalData globalVar;

        private Camera cameraMain;

        private EnemyEntity Enemy;

        GameObject MenuButtonObject;
        Button MenuButton;
        private float delay = 0;
        private float heroLifeDelay = 0;

        private bool Bool = false;

        GameObject Bullets;

        public PlayState_Joystick(GameManager managerRef, GlobalData globalRef)
        {
            manager = managerRef;
            globalVar = globalRef;
            stateName = "attackState";
            Time.timeScale = 1;
            globalVar.currentIndex = 0;
            globalVar.bulletlimit = 30;
            globalVar.currentBulletIndex = globalVar.bulletlimit;
            globalVar.isReloading = false;
            globalVar.loaded = false;
            globalVar.currentAlpha = 0;
            globalVar.instantiateEnemy = true;
            globalVar.heroIsHitting = false;
            globalVar.isPause = false;
            globalVar.enemyRemain = globalVar.totalIncomingEnemy;
            globalVar.heroLife = 100f;
            globalVar.totalMagaZine = 10;
          
        }

        void OnEnable()
        {

        }

        void pause()
        {

        }

        void resume()
        {

        }
        void gotoMenu()
        {
            DetachedEvent();
            SceneManager.LoadScene("loader");
            manager.switchState(new LoaderState(manager, globalVar, "Menu"));
        }


        public void getData()
        {
            Debug.Log(globalVar.selectedGun);
            MenuButtonObject = GameObject.Find("MenuButton");
            if (MenuButtonObject)
            {
                MenuButton = MenuButtonObject.GetComponent<Button>();
                MenuButton.onClick.AddListener(this.gotoMenu);
            }
            cameraMain = Camera.main;
        }

        GameObject FindInActiveObjectByName(string name)
        {
            Transform[] objs = Resources.FindObjectsOfTypeAll<Transform>() as Transform[];
            for (int i = 0; i < objs.Length; i++)
            {
                if (objs[i].hideFlags == HideFlags.None)
                {
                    if (objs[i].name == name)
                    {
                        return objs[i].gameObject;
                    }
                }
            }
            return null;
        }
        public void stateUpdate()
        {
            Debug.Log("gablooooo");
        }

        void wonTheRound()
        {
            DetachedEvent();
            globalVar.isWon = false;
            SceneManager.LoadScene("Win");
            manager.switchState(new WonState(manager, globalVar));
            // yield return null;
        }

        void lostRound()
        {
            DetachedEvent();
            SceneManager.LoadScene("Lost");
            manager.switchState(new LostState(manager, globalVar));
            // yield return null;
        }

        public void switchState()
        {
            SceneManager.LoadScene("loader");
            manager.switchState(new LoaderState(manager, globalVar, "MenuState"));

            // SceneManager.LoadScene("menuState");
            // manager.switchState(new menuState(manager,globalVar));
        }
        public string getStateName()
        {
            return this.stateName;
        }
        public void action(string action)
        {

        }
        public void DetachedEvent()
        {
            // manager.OnEndTouch -= TouchRelease;
            // manager.OnStartTouch -= Fire;
        }
        ~PlayState_Joystick()
        {
            DetachedEvent();
        }
    }
}

