using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Assets.Script.entity;
using Assets.Script.interfaces;
using Assets.Script.globalVar;

namespace Assets.Script.state
{
    public class ShopState : GameState
    {
        private GameManager manager;

        // private GameObject buyButtonObj;
        private Button tabOne;
        private Button tabTwo;

        private GameObject menuButtonObj;
        private Button menuButton;

        public GlobalData globalVar;

        private GameObject tabPage1;
        private GameObject tabPage2;

        private Button gun1;
        private Button gun2;
        private Button gun3;
        
        public string stateName;

        // Modal Variable
        private GameObject modal;
        private GameObject modalYesButtonObject;
        private Button modalYesButton;
        private GameObject modalNoButtonObject;
        private Button modalNoButton;

        void Start()
        {
           
        }  

        public ShopState(GameManager managerRef, GlobalData globalRef)
        {
            manager = managerRef;
            globalVar = globalRef;
            stateName = "shopState";

        }
       
        void exit()
        {
            Application.Quit();
        }

        void goToPlay()
        {
            SceneManager.LoadScene("Loader");
            manager.switchState(new LoaderState(manager, globalVar, "Menu"));
        }
        public void getData()
        {
            Debug.Log(globalVar.selectedGun);
            tabPage1 = GameObject.Find("page1");
            tabPage2 = GameObject.Find("page2");

            menuButtonObj = GameObject.Find("Menu");
            menuButton = menuButtonObj.GetComponent<Button>();
            menuButton.onClick.AddListener(this.goToPlay);

            gun1 = GameObject.Find("gun1").GetComponent<Button>();
            gun1.onClick.AddListener(delegate{this.setGun("gun1");}); 

            gun2 = GameObject.Find("gun2").GetComponent<Button>();
            gun2.onClick.AddListener(delegate{this.setGun("gun2");}); 

            gun3 = GameObject.Find("gun3").GetComponent<Button>();
            gun3.onClick.AddListener(delegate{this.setGun("gun3");}); 

            tabOne = GameObject.Find("tab1").GetComponent<Button>();
            tabOne.onClick.AddListener(this.activeTabOne);

            tabTwo = GameObject.Find("tab2").GetComponent<Button>();
            tabTwo.onClick.AddListener(this.activeTabTwo);

        }

        void back()
        {
            modal.SetActive(false);
        }

        void openExitModal()
        {
            modal.SetActive(true);
        }

        GameObject FindInActiveObjectByName(string name)
        {
            Transform[] objs = Resources.FindObjectsOfTypeAll<Transform>() as Transform[];
            for (int i = 0; i < objs.Length; i++)
            {
                if (objs[i].hideFlags == HideFlags.None)
                {
                    if (objs[i].name == name)
                    {
                        return objs[i].gameObject;
                    }
                }
            }
            return null;
        }
        public void stateUpdate()
        {

        }
        public string getStateName()
        {
            return this.stateName;
        }
        public void action(string action)
        {

        }
        void activeTabOne()
        {
            tabPage1.SetActive(false);
            tabPage2.SetActive(true);
        }
        void activeTabTwo()
        {
            tabPage1.SetActive(true);
            tabPage2.SetActive(false);
        }
        void setGun(string gun){
            globalVar.selectedGun = gun ;
            Debug.Log(globalVar.selectedGun);
        }
    }
}
