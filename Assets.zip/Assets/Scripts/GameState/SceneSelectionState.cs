using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Assets.Script.entity;
using Assets.Script.globalVar;

namespace Assets.Script.state
{
    public class SceneSelectionState : GameState
    {
        private GameManager manager;
        public string stateName = "stateSelection";

        public GameObject roundObject;
        public GameObject[] round;
        public GameObject scrollPanel;
        public GameObject scrollView;

        public GameObject Viewport;

        public RectTransform rect;
        public RectTransform scrollRect;
        public float buttonWidth;

        public GameObject comingSoonObject;

        public Text text;
        public GameObject textObject;
        public RoundSelectionButton roundButtonCS;
        public GlobalData globalVar;

        public Button btn;
        public SceneSelectionState(GameManager managerRef, GlobalData globalRef)
        {
            manager = managerRef;
            globalVar = globalRef;
            //gameData = new globalGameData();
        }
        public void OnEnable()
        {

        }

        public void stateUpdate()
        {

        }
        public void getData()
        {
            scrollPanel = GameObject.Find("MainPanel");
            if (scrollPanel)
            {
                scrollView = GameObject.Find("Scroll View");
                Viewport = GameObject.Find("Viewport");
                scrollRect = scrollPanel.GetComponent<RectTransform>();
                round = new GameObject[globalVar.round.Count];
                Debug.Log(globalVar.CurrentLevel);

                // Find all GameObjects with the specified tag.
                GameObject[] objectsWithTag = GameObject.FindGameObjectsWithTag("Round");
                int i = 0;
                // Now you can work with the array of GameObjects.
                foreach (GameObject obj in objectsWithTag)
                {
                    round[i] = obj;
                    btn = obj.GetComponent<Button>();
                    SetButtonOnClick(btn, globalVar.round[i]);
                    i++;
                }

                // for (int i = 0; i < globalVar.round.Count; i++)
                // {

                //     roundObject = Resources.Load("Prefabs/Round Selection Assets/Round") as GameObject;
                //     roundButtonCS = roundObject.GetComponent<RoundSelectionButton>();
                //     roundButtonCS.name = globalVar.round[i];

                //     round[i] = GameObject.Instantiate(roundObject) as GameObject;
                //     btn = round[i].transform.GetChild(0).GetComponent<Button>();
                //     SetButtonOnClick(btn, globalVar.round[i]);
                //     if (Viewport)
                //     {
                //         round[i].transform.parent = Viewport.transform.GetChild(0);
                //         round[i].transform.localScale = new Vector2(1, 1);
                //     }
                //     rect = round[i].GetComponent<RectTransform>();
                //     buttonWidth = rect.rect.width;
                //     rect.anchoredPosition = new Vector3(0, 0, 0);
                //     rect.localPosition = new Vector3((buttonWidth + 10) * i, 0, 0);
                // }
                // Viewport.transform.GetChild(0).localScale = new Vector3(globalVar.round.Count, 1, 0);
            }

        }
        void gotoPlay(string sceneName)
        {
            globalVar.setActiveRound(sceneName);
            // SceneManager.LoadScene("swampattack");
            // manager.switchState(new swampAttackState(manager,globalVar));

            SceneManager.LoadScene("loader");
            manager.switchState(new LoaderState(manager, globalVar, "Play"));
        }
        void SetButtonOnClick(Button btn, string name)
        {
            btn.onClick.AddListener(delegate { this.gotoPlay(name); });

        }
        public string getStateName()
        {
            return this.stateName;
        }
        public void action(string action)
        {

        }
        ~SceneSelectionState()
        {
            Debug.Log("Destructor was called SceneSelectionState");
        }
    }
}
