using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Script.interfaces;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using Assets.Script.entity;
using Assets.Script.globalVar;
using TMPro;

public class PlayManager : MonoBehaviour
{
    private GameObject heroObject;
    public GameObject HeroAfterLoad;
    private GameObject heroStartPos;
    private GameObject bulletStartPos;
    public HeroEntity Hero;

    private GameObject bulletObject;
    private GameObject[] bullet;

    private GameObject enemyObject;
    private GameObject enemy;

    private GameObject enemyStartPositionObject;

    private Khoka[] bulletComponent;
    private EnemyEntity enemyComponent;
    private EnemyEntity enemyComponent2;

    private float startPositionX;
    private float startPositionY;


    private GameObject bulletQuantityObject;
    private TextMeshProUGUI bulletQuantityText;

    private GameObject enemyPos;
    private GameObject enemyObject2;
    private GameObject[] enemy2;

    private bool invokeCalled = false;

    private GameObject TopMenu;

    // private GameObject reloadButtonObject;
    // private Button reloadButton;

    private GameObject dragObject;
    // private dragAndFire dragCS;


    public GameObject incomingSliderObject;
    public Slider incomingSlider;
    private int hasCame = 0;
    public int enemyRemain;

    private GameObject bulletGraphics;
    private GameObject[] bulletGraphicsAfterLoaded;

    private GameObject bulletGraphicsStartPos;
    private SpriteRenderer sprite;

    private GameObject coinEndPosition;

    private GameObject upperHeightLimit;
    private GameObject lowerHeightLimit;

    public Vector3[] enemyPositionArray;



    public GlobalData globalVar;
    // Start is called before the first frame update
    void Start()
    {
        TopMenu = GameObject.Find("TopMenu");
        HeroAfterLoad = GameObject.Find("Hero") as GameObject;
        Hero = HeroAfterLoad.GetComponent<HeroEntity>();
        bulletGraphicsStartPos = GameObject.Find("bulletGraphicsStartPos");

        // startPositionX = bulletStartPos.transform.position.x;
        // startPositionY = bulletStartPos.transform.position.y;
        bullet = new GameObject[globalVar.bulletlimit];
        bulletComponent = new Khoka[globalVar.bulletlimit];

        bulletGraphicsAfterLoaded = new GameObject[globalVar.bulletlimit];

        for (int i = 0; i < globalVar.bulletlimit; i++)
        {
            // INSTANTIATE BULLET GRAPHICS //
            bulletGraphics = Resources.Load("Prefabs/Bullets/bulletIndication") as GameObject;
            sprite = bulletGraphics.GetComponent<SpriteRenderer>();
            float bulletWidth = sprite.bounds.size.x + .5f;
            Debug.Log(bulletGraphicsStartPos.transform.position.x);
            Debug.Log(bulletWidth);
            bulletGraphics.transform.position = new Vector2(bulletGraphicsStartPos.transform.position.x + (bulletWidth * i), bulletGraphicsStartPos.transform.position.y);

            bulletGraphicsAfterLoaded[i] = GameObject.Instantiate(bulletGraphics) as GameObject;
            // bulletGraphicsAfterLoaded[i].transform.SetParent()
        }
        bulletQuantityObject = GameObject.Find("bulletQuantityIndication");
        bulletQuantityText = bulletQuantityObject.GetComponent<TextMeshProUGUI>();
        bulletQuantityText.text = globalVar.totalMagaZine.ToString();

        incomingSliderObject = GameObject.Find("EnemyInComing");
        incomingSlider = incomingSliderObject.GetComponent<Slider>();

    }

    private Vector3 createEnemyPosition()
    {
        var randomY = Random.Range(upperHeightLimit.transform.position.y, lowerHeightLimit.transform.position.y);
        var randomX = Random.Range(enemyPos.transform.position.x, enemyPos.transform.position.x + 5);
        Vector3 vecna = new Vector3(randomX, randomY, 0);
        if (enemyPositionArray.Length > 0)
        {
            for (int i = 0; i < enemyPositionArray.Length; i++)
            {
                if (enemyPositionArray[i].y == randomY || enemyPositionArray[i].x == randomX)
                {
                    vecna = createEnemyPosition();
                }
            }
        }
        return vecna;
    }

    public void fire()
    {
        invokeCalled = false;
        bulletGraphicsAfterLoaded[globalVar.currentIndex].SetActive(false);
    }
    public void stopFire()
    {
        // anim.SetBool("shoot", false);
        // anim.SetBool("dontShoot", true);
    }

    // Update is called once per frame
    void Update()
    {
        if (globalVar.instantiateEnemy)
        {
            instantiateEnemy();
        }
        bulletGraphicsStartPos = GameObject.Find("bulletGraphicsStartPos");
        bulletQuantityText.text = globalVar.totalMagaZine.ToString();
        if (globalVar.isReloading && globalVar.totalMagaZine > 0)
        {
            // stopFire();
            if (!invokeCalled)
                InvokeRepeating("reload", 0f, .2f);
        }
        if (globalVar.currentBulletIndex == globalVar.bulletlimit)
        {
            globalVar.isReloading = false;
            CancelInvoke("reload");
        }

        // if (globalVar.isFiring)
        // {
        //     fire(globalVar.lastMousePosition);
        // }
        // else
        // {
        //     stopFire();
        // }

    }

    void reload()
    {
        globalVar.reload();
        if (bulletGraphicsAfterLoaded[globalVar.currentBulletIndex - 1])
        {
            bulletGraphicsAfterLoaded[globalVar.currentBulletIndex - 1].SetActive(true);
        }
        invokeCalled = true;
    }
    private int createRandomNumber(int min, int max)
    {
        int randomNumberEnemy = 0;
        randomNumberEnemy = Random.Range(min, max);
        if (hasCame + randomNumberEnemy > enemyRemain)
        {
            randomNumberEnemy = enemyRemain;
        }
        else if (hasCame + randomNumberEnemy == globalVar.totalIncomingEnemy)
        {
            Debug.Log("DEBUG GAYA");
        }
        return randomNumberEnemy;
    }
    public void countEnemyandSetSliderValue(int enemyCount)
    {
        hasCame += enemyCount;
        enemyRemain -= enemyCount;
        if (enemyRemain == 0)
        {
            globalVar.isWon = true;
        }
        globalVar.enemyRemain -= enemyCount;
        if (incomingSlider)
            incomingSlider.value = hasCame;
    }

    public void instantiateEnemy()
    {
        globalVar.instantiateEnemy = false;
        if (globalVar.activeRound == "round1")
        {
            int randomNumberEnemy = createRandomNumber(2, 15);
            countEnemyandSetSliderValue(randomNumberEnemy);
            enemy2 = new GameObject[randomNumberEnemy];
            // globalVar.bornEnemy = new List<string>[randomNumberEnemy];
            enemyPositionArray = new Vector3[randomNumberEnemy];
            for (int x = 0; x < randomNumberEnemy; x++)
            {
                upperHeightLimit = GameObject.Find("BaseUpperHeightLimit");
                lowerHeightLimit = GameObject.Find("BaseLowerHeightLimit");
                enemyPos = GameObject.Find("EnemyInitialPosition");
                enemyPositionArray[x] = createEnemyPosition();
            }
            Debug.Log(enemyPositionArray);
            for (int x = 0; x < enemyPositionArray.Length; x++)
            {
                Debug.Log(enemyPositionArray[x]);
                enemyPos = GameObject.Find("EnemyInitialPosition");
                enemyObject2 = Resources.Load("Prefabs/Enemies/Enemy") as GameObject;
                enemy2[x] = GameObject.Instantiate(enemyObject2, enemyPos.transform);
                enemyComponent2 = enemy2[x].GetComponent<EnemyEntity>();
                enemyComponent2.enemytag = "enemy" + x;
                // enemyComponent2.heroLifePos = coinEndPosition.transform.position;
                globalVar.bornEnemy.Add(enemyComponent2.enemytag);
                enemyComponent2.heroPositionX = HeroAfterLoad.transform.position.x;
                enemy2[x].transform.position = new Vector3(enemyPositionArray[x].x, enemyPositionArray[x].y, 0);
                enemyComponent2.globalVar = globalVar;
            }
        }
        else if (globalVar.activeRound == "round2")
        {

            int randomNumberEnemy = createRandomNumber(3, 6);
            countEnemyandSetSliderValue(randomNumberEnemy);

            enemy2 = new GameObject[randomNumberEnemy];
            // globalVar.bornEnemy = new string[randomNumberEnemy];

            for (int x = 0; x < randomNumberEnemy; x++)
            {
                enemyPos = GameObject.Find("enemyPos");
                enemyObject2 = Resources.Load("attackPrefab/round_3") as GameObject;
                enemy2[x] = GameObject.Instantiate(enemyObject2);

                enemyComponent2 = enemy2[x].GetComponent<EnemyEntity>();
                enemyComponent2.enemytag = "enemy" + x;
                globalVar.bornEnemy.Add(enemyComponent2.enemytag);
                enemyComponent2.heroPositionX = HeroAfterLoad.transform.position.x;
                enemy2[x].transform.position = enemyPos.transform.position;
                enemyComponent2.globalVar = globalVar;
            }
        }


    }

}
