using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInput : MonoBehaviour
{
    Rigidbody2D rb2d => GetComponent<Rigidbody2D>();
    Vector2 pos;
    Vector2 pos2;
    Vector2 screenPos;
   
    private void OnMove(InputValue value){
       pos = value.Get<Vector2>();
       //Debug.Log(pos);
    }

    void Update(){
    
    }

    void FixedUpdate(){
        screenPos = Camera.main.WorldToScreenPoint(transform.position);
        if(rb2d != null){
            float posX = pos.x / 100 *  Screen.width;
            float posY = pos.y  / 100 *  Screen.height;
            
            pos2 = new Vector2(posX, posY);
            //Debug.Log(pos2);
            if(posX < screenPos.x && posY < screenPos.y){
                 rb2d.MovePosition( pos2 * 20 * Time.fixedDeltaTime );
            }
           
            // if(pos.x != 0 && pos.y != 0){
            //     // pos2 = new Vector2(pos.x + 10, pos.y+10);
            //     // rb2d.MovePosition( pos2 * 12 * Time.fixedDeltaTime);
            //     rb2d.MovePosition(rb2d.position + pos * 10 * Time.fixedDeltaTime);
            // }else{
            //     pos2 = new Vector2(0, 0);
            //     rb2d.MovePosition(pos2 * 10 * Time.fixedDeltaTime);
            // }
        }
    }
}
